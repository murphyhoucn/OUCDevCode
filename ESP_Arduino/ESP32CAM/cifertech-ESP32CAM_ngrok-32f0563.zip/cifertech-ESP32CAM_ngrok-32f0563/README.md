# ESP32CAM_ngrok

In the category of security products, you will see cameras known as ip cameras, which actually deliver the received images to the user through the cloud from anywhere in the world. In this tutorial, we are going to use ESP32-CAM boards and Cloud ngrok to build such a device with the ability to send images to different places without any restrictions. In fact, once the project is completed and launched, you will only be able to access it with a single link. 
